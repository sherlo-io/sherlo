#ifndef SHERLO_CORE_H
#define SHERLO_CORE_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SHERLO_CORE_ABI 1

#define SHERLO_ERROR_BAD_ARGUMENT -1
#define SHERLO_ERROR_SIZE_MISMATCH -2

const char *sherlo_core_version(void);

int32_t sherlo_core_abi(void);

void sherlo_free(void *memory);

#define SHERLO_PIXELS_RGBA8_PREMULTIPLIED 1

typedef struct sherlo_image {
  const uint8_t *pixels;
  int32_t width;
  int32_t height;
  int32_t stride_bytes;
  int32_t format;
} sherlo_image;

int64_t sherlo_count_different_pixels(const sherlo_image *a, const sherlo_image *b, double threshold,
                                      int32_t include_aa);

typedef struct sherlo_still_params {
  int32_t required_still_pairs;
  int32_t minimum_screenshots;
  int32_t counts_first_screenshot;
  int64_t time_limit_ms;
  double threshold;
  int32_t include_aa;
} sherlo_still_params;

typedef struct sherlo_still_state sherlo_still_state;

#define SHERLO_STILL_CONTINUE 0
#define SHERLO_STILL_STABLE 1
#define SHERLO_STILL_UNSTABLE 2

sherlo_still_state *sherlo_still_begin(const sherlo_still_params *params, int64_t now_ms);

int32_t sherlo_still_step(sherlo_still_state *state, const sherlo_image *previous,
                          const sherlo_image *current, int64_t now_ms, int32_t focus_was_cleared,
                          int64_t *different_pixels);

void sherlo_still_end(sherlo_still_state *state);

#define SHERLO_PLATFORM_IOS 1
#define SHERLO_PLATFORM_ANDROID 2

typedef struct sherlo_scroll_metrics {
  int32_t can_scroll;
  int32_t is_shown;
  double viewport_height;
  double content_height;
  double inset_top;
  double inset_bottom;
  double scroll_extent;
} sherlo_scroll_metrics;

typedef struct sherlo_scroll_candidate {
  const char *class_name;
  int32_t is_hidden;
  double alpha;
  sherlo_scroll_metrics metrics;
  int32_t is_on_screen;
  double visible_width;
  double visible_height;
} sherlo_scroll_candidate;

int32_t sherlo_scroll_candidate_is_eligible(int32_t platform,
                                            const sherlo_scroll_candidate *candidate);

int32_t sherlo_scroll_candidate_fits(int32_t platform, const sherlo_scroll_candidate *candidate,
                                     double screen_width, double screen_height);

int32_t sherlo_scroll_is_scrollable(int32_t platform, const sherlo_scroll_metrics *metrics);

typedef struct sherlo_scroll_position {
  double offset;
  double scroll_y;
} sherlo_scroll_position;

int32_t sherlo_scroll_nudge_target(int32_t platform, int32_t attempt,
                                   const sherlo_scroll_metrics *metrics,
                                   const sherlo_scroll_position *before, double *target);

int32_t sherlo_scroll_nudge_moved(int32_t platform, const sherlo_scroll_position *before,
                                  const sherlo_scroll_position *after);

typedef struct sherlo_checkpoint_plan {
  int32_t platform;
  int64_t applied_index;
  double target_offset;
  double lowest_offset;
  double highest_offset;
  double scroll_range;
  double pixels_per_point;
  double viewport_px;
  double content_px;
} sherlo_checkpoint_plan;

typedef struct sherlo_checkpoint_result {
  int32_t reached_bottom;
  int64_t applied_index;
  double applied_offset_px;
  double viewport_px;
  double content_px;
} sherlo_checkpoint_result;

int32_t sherlo_checkpoint_plan_for(int32_t platform, int64_t index, double step_px,
                                   int64_t last_index, const sherlo_scroll_metrics *metrics,
                                   double pixels_per_point, sherlo_checkpoint_plan *plan);

int32_t sherlo_checkpoint_read_back(const sherlo_checkpoint_plan *plan, double actual_offset,
                                    sherlo_checkpoint_result *result);

typedef struct sherlo_inspector_node {
  int32_t depth;
  int32_t class_index;
  int32_t is_visible;
  double x;
  double y;
  double width;
  double height;
  int32_t has_id;
  int64_t id;
  double top;
  double bottom;
} sherlo_inspector_node;

int32_t sherlo_inspector_has_room(int32_t depth, int32_t nodes_kept);

int32_t sherlo_inspector_is_on_screen(double top, double bottom, double viewport_top,
                                      double viewport_bottom);

char *sherlo_inspector_json(int32_t platform, const sherlo_inspector_node *nodes, int32_t count,
                            const char *const *class_names, int32_t class_count, double density,
                            double font_scale, double viewport_top, double viewport_bottom,
                            int64_t *length);

#ifdef __cplusplus
}
#endif

#endif
