package io.sherlo.storybookreactnative;

// Android Framework Imports
import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.content.Intent;
import android.view.View;

// React Native Bridge Imports
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.bridge.Arguments;
// Java Utility and IO Imports
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;

/**
 * Core implementation for the Sherlo module containing all business logic.
 * Manages application modes (default, storybook, testing) and provides access to helper utilities.
 */
public class SherloModuleCore {
    private static final String TAG = "SherloModule:Core";

    // Mode constants
    public static final String MODE_DEFAULT = "default";
    public static final String MODE_STORYBOOK = "storybook";
    public static final String MODE_TESTING = "testing";

    // Driver constants - who drives a testing-mode boot's own walk (see the `driver` field on
    // getSherloConstants and TestDriver in SherloModule.ts).
    public static final String DRIVER_RUNNER = "runner";
    public static final String DRIVER_CAPTURE = "capture";

    // Module state
    private static JSONObject config = null;
    private static JSONObject lastState = null;
    private static volatile String currentMode = MODE_DEFAULT;
    private static volatile String driver = null;
    private static String nativeVersion = null;

    // Guards early protocol emission to a single occurrence per process. Set once by
    // performEarlyInit() - either from SherloInitProvider.onCreate() (normal path, before
    // JS evaluates) or from this class's constructor (fallback).
    private static volatile boolean earlyInitDone = false;

    // Static fs helper shared with SherloExceptionHandler (installed in SherloInitProvider).
    // Set once in performEarlyInit(); never reassigned after that.
    private static volatile FileSystemHelper staticFsHelper = null;

    // Stored during processPackages() (before initializeWithInstance). Used by
    // SherloInitProvider at PRE_RUN_JS_BUNDLE_START to retrieve the CatalystInstance.
    private static volatile java.lang.ref.WeakReference<ReactApplicationContext> sEarlyReactContext = null;

    // Set to true by SherloJSExceptionCapture when the original JS error is written.
    // Prevents the fallback UncaughtExceptionHandler from overwriting with the wrong message.
    private static volatile boolean sJsErrorCaptured = false;

    // Helper instances
    private FileSystemHelper fileSystemHelper = null;
    private RestartHelper restartHelper = null;

    /**
     * Emits the early native protocol signals (NATIVE_INIT_STARTED, NATIVE_LOADED) when the
     * Sherlo config indicates testing mode. Idempotent - subsequent calls are no-ops.
     *
     * Invoked from SherloInitProvider.onCreate() so the signals land in protocol.sherlo
     * before Application.onCreate() / JS evaluation, matching iOS __attribute__((constructor))
     * semantics. In non-testing / production mode this is a silent no-op, so host apps that
     * bundle the SDK without running tests incur no file writes.
     *
     * All work is wrapped in try/catch - a ContentProvider that throws from onCreate kills
     * app startup for every user of the SDK.
     *
     * @param context Any non-null Android context (application context is sufficient).
     */
    public static synchronized void performEarlyInit(Context context) {
        if (earlyInitDone) return;
        earlyInitDone = true;

        try {
            FileSystemHelper fsHelper = new FileSystemHelper(context);
            staticFsHelper = fsHelper;
            JSONObject earlyConfig = ConfigHelper.loadConfig(fsHelper);
            if (earlyConfig == null) return;

            String mode = ConfigHelper.determineModeFromConfig(earlyConfig);
            if (!MODE_TESTING.equals(mode)) return;

            currentMode = mode;

            ProtocolHelper.writeNativeInitStarted(fsHelper);

            JSONObject earlyLastState = LastStateHelper.getLastState(fsHelper);
            String requestId = null;
            if (earlyLastState != null) {
                try {
                    requestId = earlyLastState.getString("requestId");
                } catch (org.json.JSONException e) {
                    // requestId missing is expected on first run - not an error
                }
            }
            ProtocolHelper.writeNativeLoaded(fsHelper, requestId);
        } catch (Throwable t) {
            Log.e(TAG, "Failed to perform early init", t);
        }
    }

    /**
     * Initializes the module with the React context and sets up all required helpers.
     * Loads configuration and determines the initial mode to use.
     *
     * @param reactContext The React application context
     */
    public SherloModuleCore(ReactApplicationContext reactContext, Activity activity) {
        // Store context before initializeWithInstance() runs so PRE_RUN_JS_BUNDLE_START can retrieve it.
        storeEarlyReactContext(reactContext);
        this.fileSystemHelper = new FileSystemHelper(reactContext);

        // Fallback - normal Android startup already runs this via SherloInitProvider before
        // Application.onCreate(). The call is idempotent so the double-invocation costs nothing.
        performEarlyInit(reactContext);

        this.restartHelper = new RestartHelper(reactContext);

        this.nativeVersion = SherloJsonHelper.getNativeVersion(reactContext);

        this.config = ConfigHelper.loadConfig(this.fileSystemHelper);

        String persistedMode = restartHelper.getPersistedMode();
        if (persistedMode != null) {
            // We have a valid persisted mode that hasn't expired, use it
            this.currentMode = persistedMode;
            Log.d(TAG, "Using persisted mode: " + currentMode);

            // A capture drove this restart (see openTesting): there is no config.sherlo on disk for
            // it, so the config-based branch below - the one that would otherwise populate `config`
            // and `lastState` - never runs. What openTesting handed across the restart is read here
            // instead, and built into the SAME shape the config-based branch produces: the story the
            // capture is landing on, in `lastState`, and the config it is running with, in `config` -
            // same fields, same types, as a run's own config.sherlo/protocol.sherlo would produce, so
            // nothing downstream (getConfig(), TestingMode/Storybook.tsx's
            // `lastState?.nextSnapshot.storyId`) has to know which way either one arrived.
            if (MODE_TESTING.equals(currentMode)) {
                this.driver = DRIVER_CAPTURE;

                String initialConfigJson = restartHelper.getPersistedInitialConfigJson();
                this.config = parseConfigJson(initialConfigJson);

                String initialStoryId = restartHelper.getPersistedInitialStoryId();
                if (initialStoryId != null && !initialStoryId.isEmpty()) {
                    this.lastState = lastStateForInitialStory(initialStoryId);
                }
            }
        } else if (this.config != null) {
            // Fallback to config-based mode
            this.currentMode = ConfigHelper.determineModeFromConfig(this.config);
            Log.d(TAG, "Using config-based mode: " + currentMode);

            if (currentMode.equals(MODE_TESTING)) {
                this.driver = DRIVER_RUNNER;
                this.lastState = LastStateHelper.getLastState(this.fileSystemHelper);
            }
        }

        Log.d(TAG, "SherloModuleCore initialized with mode: " + currentMode);
    }

    /**
     * The `lastState` shape a real run's own protocol file produces (see LastStateHelper), built
     * instead from a story handed over across a capture's restart. `requestId` is the empty string -
     * a capture has none - matching LastStateHelper's own default for the same field, rather than
     * leaving the key out: same fields, same types, as a run's own lastState.
     */
    private static JSONObject lastStateForInitialStory(String storyId) {
        try {
            JSONObject nextSnapshot = new JSONObject();
            nextSnapshot.put("storyId", storyId);
            JSONObject state = new JSONObject();
            state.put("nextSnapshot", nextSnapshot);
            state.put("requestId", "");
            return state;
        } catch (org.json.JSONException e) {
            Log.e(TAG, "Failed to build lastState for initial story", e);
            return null;
        }
    }

    /**
     * The `config` a capture's restart hands across in memory (see openTesting), parsed into the
     * same shape ConfigHelper.loadConfig produces from a run's own config.sherlo. Never throws -
     * a parse failure here must not crash the app any more than a corrupt config.sherlo does.
     */
    private static JSONObject parseConfigJson(String configJson) {
        if (configJson == null || configJson.isEmpty()) return null;
        try {
            return new JSONObject(configJson);
        } catch (org.json.JSONException e) {
            Log.e(TAG, "Failed to parse config handed over from a capture's restart", e);
            return null;
        }
    }

    /**
     * Returns the current mode string. Safe to call before constructor - falls back to
     * MODE_DEFAULT. Used by the JSI bindings (SherloModuleJSIBindings.cpp) to read the
     * mode synchronously on the JS thread before bundle evaluation starts.
     */
    public static String getCurrentMode() {
        return currentMode != null ? currentMode : MODE_DEFAULT;
    }

    /**
     * Returns the static FileSystemHelper created during performEarlyInit(), or null if
     * performEarlyInit() has not run yet. Used by SherloInitProvider's uncaught-exception
     * handler to write JS_ERROR to protocol without needing a ReactContext.
     */
    public static FileSystemHelper getStaticFsHelper() {
        return staticFsHelper;
    }

    public static void storeEarlyReactContext(ReactApplicationContext ctx) {
        sEarlyReactContext = new java.lang.ref.WeakReference<>(ctx);
    }

    public static ReactApplicationContext getEarlyReactContext() {
        java.lang.ref.WeakReference<ReactApplicationContext> ref = sEarlyReactContext;
        return ref != null ? ref.get() : null;
    }

    public static void markJsErrorCaptured() {
        sJsErrorCaptured = true;
    }

    public static boolean isJsErrorCaptured() {
        return sJsErrorCaptured;
    }

    /**
     * Returns constants exposed to the JavaScript side.
     * Provides access to the current mode, configuration and last state.
     *
     * @return A map containing the module constants
     */
    public WritableMap getSherloConstants() {
        final WritableMap constants = Arguments.createMap();
        constants.putString("mode", this.currentMode);
        constants.putString("config", this.config != null ? this.config.toString() : null);
        constants.putString("lastState", this.lastState != null ? this.lastState.toString() : null);
        constants.putString("nativeVersion", this.nativeVersion);
        constants.putString("driver", this.driver);
        // The C core's version, for the START that reports which core ran. Only a run reads it, so
        // only testing mode loads the C core to ask.
        constants.putString("compiledCoreVersion",
                MODE_TESTING.equals(this.currentMode) ? CompiledCore.version() : null);
        return constants;
    }

    /**
     * Toggles between Storybook and default modes.
     * If currently in Storybook mode, switches to default, otherwise switches to Storybook.
     */
    public void toggleStorybook() {
        String newMode = currentMode.equals(MODE_STORYBOOK) ? MODE_DEFAULT : MODE_STORYBOOK;
        restartHelper.restart(newMode);
    }

    /**
     * Switches to Storybook mode and restarts the React context.
     */
    public void openStorybook() {
        restartHelper.restart(MODE_STORYBOOK);
    }

    /**
     * Switches to default mode and restarts the React context.
     */
    public void closeStorybook() {
        restartHelper.restart(MODE_DEFAULT);
    }

    /**
     * Switches to testing mode and restarts the React context.
     * The restart a capture asks for: the same full process restart `sherlo open` uses,
     * but into testing mode so the app comes back up with isRunningVisualTests true.
     *
     * @param storyId    the story to hand the restarted app over as its initial selection (see
     *                   lastStateForInitialStory), or empty when there is none to hand over.
     * @param configJson the config to hand the restarted app over as `config` (see parseConfigJson)
     *                   - a capture has no config.sherlo of its own, so the JS caller sends
     *                   getConfigOrDefault()'s answer instead (see captureTransport.ts).
     */
    public void openTesting(String storyId, String configJson) {
        restartHelper.restart(MODE_TESTING, storyId, configJson);
    }

    /**
     * Writes a NATIVE_ERROR JSON line to protocol.sherlo.
     *
     * @param errorCode The error code (e.g. ERROR_SDK_COMPATIBILITY)
     * @param message Human-readable error description
     */
    public void sendNativeError(String errorCode, String message, String dataJson) {
        if (!MODE_TESTING.equals(currentMode)) return;
        ProtocolHelper.writeNativeError(this.fileSystemHelper, errorCode, message, dataJson);
    }

    /**
     * Synchronously writes a JS_ERROR entry for module-eval errors caught by the metro __r polyfill.
     * Must never throw. Returns true on success, false on failure.
     */
    public boolean reportEarlyJsError(String name, String message, String stack) {
        Log.i(TAG, "[diag native] reportEarlyJsError CALLED with: " + name + "/" + message);
        try {
            if (this.fileSystemHelper != null) {
                this.fileSystemHelper.appendFile("sherlo-diag.log",
                    "[diag native] reportEarlyJsError CALLED with: " + name + "/" + message + "\n");
            }
        } catch (Throwable diagErr) { /* ignore */ }
        // Defense in depth: even if the JS-side gate (metro/polyfill.js) is bypassed,
        // refuse to write JS errors to protocol.sherlo unless in testing mode. This
        // makes a polyfill-bug failure mode 'no error captured' not 'protocol polluted'.
        if (!MODE_TESTING.equals(currentMode)) {
            Log.i(TAG, "[diag native] reportEarlyJsError: mode=" + currentMode + " (not testing) - returning false");
            try {
                if (this.fileSystemHelper != null) {
                    this.fileSystemHelper.appendFile("sherlo-diag.log",
                        "[diag native] reportEarlyJsError: mode=" + currentMode + " (not testing) - returning false\n");
                }
            } catch (Throwable diagErr) { /* ignore */ }
            return false;
        }
        try {
            ProtocolHelper.writeEarlyJsError(this.fileSystemHelper, name, message, stack);
            // Set the flag so the native UncaughtExceptionHandler fallback knows
            // a correct JS_ERROR was already written and skips the wrong secondary exception.
            markJsErrorCaptured();
            Log.i(TAG, "[diag native] reportEarlyJsError returning - write completed");
            try {
                if (this.fileSystemHelper != null) {
                    this.fileSystemHelper.appendFile("sherlo-diag.log",
                        "[diag native] reportEarlyJsError returning - write completed\n");
                }
            } catch (Throwable diagErr) { /* ignore */ }
            return true;
        } catch (Exception e) {
            Log.e(TAG, "reportEarlyJsError failed", e);
            return false;
        }
    }

    /**
     * Appends base64 encoded content to a file.
     * 
     * @param filename The name of the file to append to
     * @param base64Content The base64 encoded content to append
     * @param promise Promise to resolve or reject
     */
    public void appendFile(String filename, String base64Content, Promise promise) {
        fileSystemHelper.appendFileWithPromise(filename, base64Content, promise);
    }

    /**
     * Reads a file and returns its content as a base64 encoded string.
     * 
     * @param filename The name of the file to read
     * @param promise Promise to resolve with the content or reject with an error
     */
    public void readFile(String filename, Promise promise) {
        fileSystemHelper.readFileWithPromise(filename, promise);
    }

    /**
     * Gets UI inspector data from the current view hierarchy.
     * 
     * @param activity The current activity
     * @param promise Promise to resolve with the inspector data or reject with an error
     */
    public void getInspectorData(Activity activity, Promise promise) {
        InspectorHelper.getInspectorData(activity, promise);
    }

    /**
     * Checks if the UI is stable by comparing consecutive screenshots.
     * 
     * @param activity The current activity
     * @param requiredMatches The number of consecutive matching screenshots needed
     * @param minScreenshotsCount The minimum number of screenshots to take when checking for stability
     * @param intervalMs The interval between each screenshot (in milliseconds)
     * @param timeoutMs The overall timeout (in milliseconds)
     * @param saveScreenshots Whether to save screenshots to filesystem during tests
     * @param threshold Matching threshold (0.0 to 1.0); smaller values are more sensitive
     * @param includeAA If false, ignore anti-aliased pixels when counting differences
     * @param promise Promise to resolve with the stability result or reject with an error
     */
    public void stabilize(Activity activity, int requiredMatches, int minScreenshotsCount, int intervalMs, int timeoutMs, boolean saveScreenshots, double threshold, boolean includeAA, Promise promise) {
        StabilityHelper.stabilize(activity, requiredMatches, minScreenshotsCount, intervalMs, timeoutMs, saveScreenshots, threshold, includeAA, promise);
    }

    /**
     * Native paint barrier: force a redraw and resolve on the next
     * real frame commit, capped at timeoutMs.
     *
     * @param activity  The current activity
     * @param timeoutMs Cap on how long to wait for a frame commit (ms)
     * @param promise   Resolves true if a frame commit was observed, false on timeout
     */
    public void awaitFrameCommit(Activity activity, int timeoutMs, Promise promise) {
        StabilityHelper.awaitFrameCommit(activity, timeoutMs, promise);
    }

    // ============ Scroll Detection ============

    private static final boolean SCROLL_DEBUG = true;

    // Locked scroll view from isScrollable(), reused by scrollToCheckpoint()
    private View lockedScrollView = null;

    /**
     * Detects if the currently visible screen can be vertically scrolled for long-screenshot capture.
     * Resolves with a map: {scrollable: boolean, scrollViewFrame?: {x, y, width, height}} in physical pixels.
     *
     * @param activity The current activity
     * @param promise Promise to resolve with the result map
     */
    public void isScrollable(Activity activity, Promise promise) {
        if (activity == null) {
            if (SCROLL_DEBUG) {
                Log.d(TAG, "isScrollable: No activity");
            }
            WritableMap noResult = Arguments.createMap();
            noResult.putBoolean("scrollable", false);
            promise.resolve(noResult);
            return;
        }

        activity.runOnUiThread(() -> {
            try {
                WritableMap result = detectScrollableView(activity);
                promise.resolve(result);
            } catch (Exception e) {
                if (SCROLL_DEBUG) {
                    Log.e(TAG, "isScrollable exception", e);
                }
                WritableMap noResult = Arguments.createMap();
                noResult.putBoolean("scrollable", false);
                promise.resolve(noResult);
            }
        });
    }

    // ============ Checkpoint Scrolling ============

    /**
     * Deterministically scrolls to a checkpoint index.
     *
     * @param index The checkpoint index (0-based)
     * @param offset The vertical offset per checkpoint (in pixels)
     * @param maxIndex The maximum allowed index
     */
    public void scrollToCheckpoint(Activity activity, double index, double offset, double maxIndex, Promise promise) {
        if (activity == null) {
            promise.resolve(createScrollResult(true, 0, 0, 0, 0, null));
            return;
        }

        activity.runOnUiThread(() -> {
            try {
                WritableMap result = performScrollToCheckpoint(activity, (int)index, (int)offset, (int)maxIndex);
                promise.resolve(result);
            } catch (Exception e) {
                if (SCROLL_DEBUG) {
                    Log.e(TAG, "scrollToCheckpoint exception", e);
                }
                promise.resolve(createScrollResult(true, 0, 0, 0, 0, null));
            }
        });
    }

    private WritableMap performScrollToCheckpoint(Activity activity, int index, int offsetPx, int maxIndex) {
        // 1. Use locked scroll view from isScrollable() - no re-detection
        View candidate = lockedScrollView;

        if (candidate == null || candidate.getWindowToken() == null) {
            if (SCROLL_DEBUG) {
                Log.d(TAG, "scrollToCheckpoint: No locked candidate found");
            }
            return createScrollResult(true, 0, 0, 0, 0, null);
        }

        // Suppress scroll indicators for the duration of testing
        candidate.setVerticalScrollBarEnabled(false);
        candidate.setHorizontalScrollBarEnabled(false);

        // 2. Read Metrics
        int viewportPx = candidate.getHeight();

        int range = getScrollRangeViaReflection(candidate);
        if (range <= 0) {
            if (SCROLL_DEBUG) {
                Log.d(TAG, "scrollToCheckpoint: Could not determine scroll range");
            }
        }

        int extent = getScrollExtentViaReflection(candidate);

        // 3. Plan: the C core keeps the index in range and the target inside the scroll range
        int targetPx = CompiledCore.nativeCheckpointTarget(index, offsetPx, maxIndex, viewportPx, range, extent);

        // 4. Apply Scroll
        int currentOffset = getScrollOffsetViaReflection(candidate);
        int delta = targetPx - currentOffset;

        if (SCROLL_DEBUG) {
            Log.d(TAG, "scrollToCheckpoint: index=" + index + ", target=" + targetPx + ", current=" + currentOffset + ", delta=" + delta);
        }

        if (Math.abs(delta) > 0) {
            scrollViewBy(candidate, delta);
        }

        // 5. Read Back: the offset reached, and whether this is the bottom
        int actualOffsetPx = getScrollOffsetViaReflection(candidate);
        int[] result = new int[5];
        CompiledCore.nativeCheckpointReadBack(index, offsetPx, maxIndex, viewportPx, range, extent, actualOffsetPx, result);

        WritableMap frame = getScrollViewFrameInPixels(candidate);
        return createScrollResult(result[0] == 1, result[1], result[2], result[3], result[4], frame);
    }

    private WritableMap createScrollResult(boolean reachedBottom, int appliedIndex, int appliedOffsetPx, int viewportPx, int contentPx, WritableMap scrollViewFrame) {
        WritableMap map = Arguments.createMap();
        map.putBoolean("reachedBottom", reachedBottom);
        map.putInt("appliedIndex", appliedIndex);
        map.putInt("appliedOffsetPx", appliedOffsetPx);
        map.putInt("viewportPx", viewportPx);
        map.putInt("contentPx", contentPx);
        if (scrollViewFrame != null) {
            map.putMap("scrollViewFrame", scrollViewFrame);
        }
        return map;
    }

    /**
     * Get vertical scroll extent using reflection since the method is protected.
     */
    private int getScrollExtentViaReflection(View view) {
        try {
            java.lang.reflect.Method method = View.class.getDeclaredMethod("computeVerticalScrollExtent");
            method.setAccessible(true);
            return (Integer) method.invoke(view);
        } catch (Exception e) {
            if (SCROLL_DEBUG) {
                Log.d(TAG, "Failed to get scroll extent via reflection: " + e.getMessage());
            }
            return -1;
        }
    }

    /**
     * Main detection logic for scrollable views. Returns map with scrollable + optional scrollViewFrame.
     */
    private WritableMap detectScrollableView(Activity activity) {
        View decorView = activity.getWindow().getDecorView();
        WritableMap noResult = Arguments.createMap();
        noResult.putBoolean("scrollable", false);

        if (decorView == null) {
            if (SCROLL_DEBUG) {
                Log.d(TAG, "isScrollable: No decor view");
            }
            return noResult;
        }

        // Reset lock for each new story detection
        lockedScrollView = null;

        String unusableReason = CompiledCore.unusableReason();
        if (unusableReason != null) {
            Log.w(TAG, "isScrollable: the C core cannot decide - " + unusableReason);
            return noResult;
        }

        // BFS from root to find the best user-facing scrollable view
        View candidate = findBestScrollViewBFS(decorView);

        if (candidate == null) {
            if (SCROLL_DEBUG) {
                Log.d(TAG, "isScrollable: No scrollable candidate found");
            }
            return noResult;
        }

        if (SCROLL_DEBUG) {
            Log.d(TAG, "isScrollable: Candidate found via BFS, class: " + candidate.getClass().getSimpleName());
        }

        // Suppress scroll indicators for the duration of testing
        candidate.setVerticalScrollBarEnabled(false);
        candidate.setHorizontalScrollBarEnabled(false);

        boolean scrollable = isScrollableByMetrics(candidate);

        if (!scrollable) {
            scrollable = validateWithNudge(candidate);
            if (SCROLL_DEBUG) {
                Log.d(TAG, "isScrollable: Nudge validation result: " + scrollable);
            }
        } else {
            if (SCROLL_DEBUG) {
                Log.d(TAG, "isScrollable: Metric check passed");
            }
        }

        if (!scrollable) {
            return noResult;
        }

        // Lock the candidate for reuse in scrollToCheckpoint()
        lockedScrollView = candidate;

        WritableMap frame = getScrollViewFrameInPixels(candidate);
        WritableMap result = Arguments.createMap();
        result.putBoolean("scrollable", true);
        result.putMap("scrollViewFrame", frame);
        return result;
    }

    /**
     * BFS traversal from root to find the first (shallowest / most-wrapping) scrollable view.
     * BFS guarantees breadth-first order so the outermost scrollable view is found first. The C core
     * judges each view that can scroll vertically as the walk reaches it - VISIBLE and not
     * framework-internal, then scrollable by its numbers and big enough - and the walk stops at the
     * first that fits. Only an eligible view has its range read, as before.
     */
    private View findBestScrollViewBFS(View root) {
        java.util.LinkedList<View> queue = new java.util.LinkedList<>();
        queue.add(root);

        while (!queue.isEmpty()) {
            View view = queue.poll();

            if (view.canScrollVertically(1) || view.canScrollVertically(-1)) {
                String className = view.getClass().getName();
                boolean isShown = view.getVisibility() == View.VISIBLE;
                if (CompiledCore.nativeScrollCandidateIsEligible(className, isShown)) {
                    int height = view.getHeight();
                    int range = getScrollRangeViaReflection(view);
                    // Check minimum area - skip tiny scrollable views (toasts, badges, etc.)
                    android.graphics.Rect rect = new android.graphics.Rect();
                    if (CompiledCore.nativeScrollIsScrollable(true, isShown, height, range) && view.getGlobalVisibleRect(rect)) {
                        boolean fits = CompiledCore.nativeScrollCandidateFits(className, isShown, height, range, true,
                                rect.width(), rect.height(), root.getWidth(), root.getHeight());
                        if (fits) {
                            if (SCROLL_DEBUG) {
                                Log.d(TAG, "BFS: Found scrollable view " + view.getClass().getSimpleName());
                            }
                            return view;
                        }
                        if (SCROLL_DEBUG) {
                            Log.d(TAG, "BFS: Skipping too-small scrollable view " + view.getClass().getSimpleName());
                        }
                    }
                }
            }

            if (view instanceof android.view.ViewGroup) {
                android.view.ViewGroup group = (android.view.ViewGroup) view;
                for (int i = 0; i < group.getChildCount(); i++) {
                    queue.add(group.getChildAt(i));
                }
            }
        }

        return null;
    }

    /**
     * Returns the scroll view's frame in physical pixels (global screen coordinates).
     *
     * Uses getLocationInWindow + view.getWidth()/view.getHeight() instead of
     * getGlobalVisibleRect so that partially-clipped views (e.g. when the bottom
     * of the scroll container sits just above the keyboard or navigation bar) still
     * report their full logical dimensions rather than the clipped visible rect.
     */
    private WritableMap getScrollViewFrameInPixels(View view) {
        int[] location = new int[2];
        view.getLocationInWindow(location);
        WritableMap frame = Arguments.createMap();
        frame.putInt("x", location[0]);
        frame.putInt("y", location[1]);
        frame.putInt("width", view.getWidth());
        frame.putInt("height", view.getHeight());
        return frame;
    }

    /**
     * Metric-based check for scrollability: the view's numbers, judged by the C core. A range that
     * cannot be read leaves the platform's own word that the view can scroll.
     */
    private boolean isScrollableByMetrics(View view) {
        boolean canScroll = view.canScrollVertically(1) || view.canScrollVertically(-1);
        boolean isShown = view.getVisibility() == View.VISIBLE;
        // Use view height as extent (viewport height)
        int height = view.getHeight();
        // Try to get scroll range using reflection since computeVerticalScrollRange is protected
        int range = getScrollRangeViaReflection(view);

        if (SCROLL_DEBUG) {
            Log.d(TAG, "Scroll metrics - range: " + range + ", extent: " + height + ", canScroll: " + canScroll);
        }

        return CompiledCore.nativeScrollIsScrollable(canScroll, isShown, height, range);
    }

    /**
     * Get vertical scroll range using reflection since the method is protected.
     */
    private int getScrollRangeViaReflection(View view) {
        try {
            java.lang.reflect.Method method = View.class.getDeclaredMethod("computeVerticalScrollRange");
            method.setAccessible(true);
            return (Integer) method.invoke(view);
        } catch (Exception e) {
            if (SCROLL_DEBUG) {
                Log.d(TAG, "Failed to get scroll range via reflection: " + e.getMessage());
            }
            return -1;
        }
    }

    /**
     * Get vertical scroll offset using reflection since the method is protected.
     */
    private int getScrollOffsetViaReflection(View view) {
        try {
            java.lang.reflect.Method method = View.class.getDeclaredMethod("computeVerticalScrollOffset");
            method.setAccessible(true);
            return (Integer) method.invoke(view);
        } catch (Exception e) {
            if (SCROLL_DEBUG) {
                Log.d(TAG, "Failed to get scroll offset via reflection: " + e.getMessage());
            }
            // Fallback to getScrollY
            return view.getScrollY();
        }
    }

    /**
     * Validate control by tiny nudge + restore: the C core says how far to scroll for each attempt
     * (down, then up), the view is scrolled, read back and scrolled back by what its scrollY moved,
     * and the C core judges whether it moved - by its scrollY or its computed offset.
     */
    private boolean validateWithNudge(View view) {
        int originalScrollY = view.getScrollY();
        int originalOffset = getScrollOffsetViaReflection(view);

        int[] distance = new int[1];
        for (int attempt = 0; CompiledCore.nativeScrollNudgeTarget(attempt, originalOffset, originalScrollY, distance); attempt++) {
            scrollViewBy(view, distance[0]);

            int newScrollY = view.getScrollY();
            int newOffset = getScrollOffsetViaReflection(view);

            // Restore
            scrollViewBy(view, -(newScrollY - originalScrollY));

            boolean moved = CompiledCore.nativeScrollNudgeMoved(originalOffset, originalScrollY, newOffset, newScrollY);

            if (SCROLL_DEBUG) {
                Log.d(TAG, "Nudge " + attempt + ": originalScrollY=" + originalScrollY + ", newScrollY=" + newScrollY +
                           ", originalOffset=" + originalOffset + ", newOffset=" + newOffset + ", moved=" + moved);
            }

            if (moved) {
                return true;
            }
        }

        return false;
    }

    /**
     * Scroll a view by the given amount using the appropriate method.
     * Uses reflection for optional dependencies (RecyclerView, NestedScrollView) to avoid compile-time dependency.
     */
    private void scrollViewBy(View view, int dy) {
        if (view instanceof android.widget.ScrollView) {
            ((android.widget.ScrollView) view).scrollBy(0, dy);
            return;
        }
        
        if (view instanceof android.webkit.WebView) {
            ((android.webkit.WebView) view).scrollBy(0, dy);
            return;
        }
        
        // Try NestedScrollView via reflection (optional dependency)
        if (tryScrollByClassName(view, "androidx.core.widget.NestedScrollView", dy)) {
            return;
        }
        
        // Try RecyclerView via reflection (optional dependency)
        if (tryScrollByClassName(view, "androidx.recyclerview.widget.RecyclerView", dy)) {
            return;
        }
        
        // Generic fallback - use View.scrollBy which is always available
        view.scrollBy(0, dy);
    }

    /**
     * Try to scroll a view if it matches the given class name using reflection.
     * Returns true if the scroll was attempted (class matched), false otherwise.
     */
    private boolean tryScrollByClassName(View view, String className, int dy) {
        try {
            Class<?> clazz = Class.forName(className);
            if (clazz.isInstance(view)) {
                view.scrollBy(0, dy);
                return true;
            }
        } catch (ClassNotFoundException e) {
            // Class not available, skip
        }
        return false;
    }
} 