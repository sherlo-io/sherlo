package io.sherlo.storybookreactnative;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.Choreographer;
import android.view.PixelCopy;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.inputmethod.InputMethodManager;

import com.facebook.react.bridge.Promise;

import java.util.concurrent.atomic.AtomicBoolean;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Helper for checking UI stability by comparing consecutive screenshots.
 * Used to determine when animations and rendering have completed.
 */
public class StabilityHelper {
    private static final String TAG = "SherloModule:StabilityHelper";

    public interface StabilityCallback {
        void onResult(boolean isStable);
    }

    /**
     * Checks if the UI is stable by taking consecutive screenshots and comparing them (see
     * checkIfStable). Resolves the promise true once the required number of matching
     * screenshots is reached, false once the timeout is exceeded.
     */
    public static void stabilize(Activity activity, int requiredMatches, int minScreenshotsCount, int intervalMs,
            int timeoutMs, double threshold, boolean includeAA, Promise promise) {
        StabilityHelper helper = new StabilityHelper();
        helper.checkIfStable(activity, requiredMatches, minScreenshotsCount, intervalMs, timeoutMs,
                threshold, includeAA, new StabilityCallback() {
                    @Override
                    public void onResult(boolean isStable) {
                        promise.resolve(isStable);
                    }
                });
    }

    /**
     * Native paint barrier.
     *
     * Forces a redraw of the root view and resolves only once the GPU has
     * actually committed a frame - closing the React "committed-but-not-painted"
     * gap that let PixelCopy read a blank / stale surface. Content-agnostic.
     *
     * API 29+ uses ViewTreeObserver.registerFrameCommitCallback (the same signal
     * Jetpack Compose's captureToImage waits on). Below 29 there is no
     * frame-commit API, so we resolve(false) immediately and proceed best-effort.
     * On timeout we resolve(false): the caller treats a paint-barrier timeout as
     * best-effort and proceeds to the stability loop (design decision 3).
     *
     * @param activity  Current activity (resolves false if null).
     * @param timeoutMs Cap on how long to wait for a frame commit.
     * @param promise   Resolves true if a frame commit was observed, false on timeout/error.
     */
    public static void awaitFrameCommit(Activity activity, int timeoutMs, Promise promise) {
        if (activity == null) {
            promise.resolve(false);
            return;
        }

        final View rootView = activity.getWindow().getDecorView().getRootView();
        final Handler mainHandler = new Handler(Looper.getMainLooper());
        final AtomicBoolean settled = new AtomicBoolean(false);

        mainHandler.post(() -> {
            try {
                // No frame-commit API below API 29: resolve(false) immediately and
                // let the caller proceed best-effort to the stability loop (same as
                // today's no-barrier behavior).
                if (Build.VERSION.SDK_INT < 29) {
                    if (settled.compareAndSet(false, true)) {
                        promise.resolve(false);
                    }
                    return;
                }

                final ViewTreeObserver observer = rootView.getViewTreeObserver();

                // Force the next frame to be produced.
                rootView.invalidate();
                rootView.requestLayout();

                // registerFrameCommitCallback is one-shot: it auto-unregisters
                // after firing, so no explicit removal is needed.
                observer.registerFrameCommitCallback(() -> {
                    if (settled.compareAndSet(false, true)) {
                        promise.resolve(true);
                    }
                });

                // Kick a redraw on the next animation frame.
                rootView.postInvalidateOnAnimation();

                // Timeout: warn + proceed (best-effort catch-up).
                mainHandler.postDelayed(() -> {
                    if (settled.compareAndSet(false, true)) {
                        Log.w(TAG, "awaitFrameCommit timed out after " + timeoutMs + "ms; proceeding best-effort");
                        promise.resolve(false);
                    }
                }, Math.max(timeoutMs, 1));
            } catch (Throwable t) {
                Log.w(TAG, "awaitFrameCommit failed", t);
                if (settled.compareAndSet(false, true)) {
                    promise.resolve(false);
                }
            }
        });
    }

    /**
     * Captures a screenshot of the activity's root view.
     * This must NOT block the UI thread; it performs UI nudges on the main thread
     * but waits on a background thread.
     */
    public Bitmap captureScreenshot(Activity activity) {
        final View rootView = activity.getWindow().getDecorView().getRootView();
        final int width = rootView.getWidth();
        final int height = rootView.getHeight();
        if (width <= 0 || height <= 0) {
            throw new RuntimeException("Impossible to snapshot the view: view is invalid");
        }

        // 0) Ensure we're NOT running this method on the UI thread to avoid deadlocks
        if (Looper.myLooper() == Looper.getMainLooper()) {
            Log.w(TAG,
                    "captureScreenshot called on UI thread; this can cause timeouts. Consider calling from a background thread.");
        }

        // 1) PRE-CAPTURE NUDGE: on UI thread, rebuild layer + invalidate + wait 2
        // vsyncs
        final CountDownLatch readyForCopy = new CountDownLatch(1);
        runOnUiThread(activity, () -> {
            try {
                // Toggle layer type to rebuild hardware layer safely
                int lt = rootView.getLayerType();
                rootView.setLayerType(View.LAYER_TYPE_NONE, null);
                rootView.setLayerType(lt, null);

                // Schedule a redraw next frame
                rootView.postInvalidateOnAnimation();

                // Wait two frames to ensure fresh content is rendered
                Choreographer.getInstance().postFrameCallback(
                        ft -> Choreographer.getInstance().postFrameCallback(ft2 -> readyForCopy.countDown()));
            } catch (Throwable t) {
                Log.w(TAG, "Pre-capture nudge failed", t);
                readyForCopy.countDown();
            }
        });
        try {
            readyForCopy.await(500, TimeUnit.MILLISECONDS);
        } catch (InterruptedException ignored) {
        }

        // 2) Allocate destination bitmap
        final Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);

        // 3) PixelCopy from the Window using a background handler for the callback
        final CountDownLatch pixelCopyLatch = new CountDownLatch(1);
        final AtomicInteger resultHolder = new AtomicInteger(-1);

        // Use a dedicated handler thread for PixelCopy callbacks
        HandlerThread ht = new HandlerThread("SherloPixelCopy");
        ht.start();
        Handler copyHandler = new Handler(ht.getLooper());

        try {
            PixelCopy.request(activity.getWindow(), bitmap, copyResult -> {
                resultHolder.set(copyResult);
                pixelCopyLatch.countDown();
            }, copyHandler);

            // Wait up to 1s for the copy to finish
            if (!pixelCopyLatch.await(1000, TimeUnit.MILLISECONDS)) {
                Log.d(TAG, "PixelCopy timeout; will fall back to View#draw");
            }
        } catch (Throwable t) {
            Log.w(TAG, "PixelCopy threw; will fall back to View#draw", t);
        } finally {
            try {
                ht.quitSafely();
            } catch (Throwable ignored) {
            }
        }

        // 4) Fallback: draw the view hierarchy if copy failed or returned no data
        if (resultHolder.get() != PixelCopy.SUCCESS) {
            runOnUiThread(activity, () -> {
                try {
                    Canvas canvas = new Canvas(bitmap);
                    rootView.draw(canvas);
                } catch (Throwable t) {
                    Log.e(TAG, "Error while drawing canvas fallback", t);
                }
            });
        }

        return bitmap;
    }

    /**
     * The run's config counts screenshots in a row that match; the C core counts pairs in a row
     * with no differing pixel. Three matching screenshots are two still pairs, so a still screen
     * ends the loop at its third screenshot. iOS keeps the same rule.
     */
    static int stillPairsForMatchingScreenshots(int matchingScreenshots) {
        return Math.max(matchingScreenshots - 1, 1);
    }

    /**
     * Checks for UI stability by comparing consecutive screenshots, every interval, until
     * requiredMatches screenshots in a row match (true) or, past timeoutMs and at least
     * minScreenshotsCount screenshots, the latest two differ (false). threshold (0.0 to 1.0,
     * smaller is more sensitive) and includeAA decide which pixels differ.
     */
    public void checkIfStable(final Activity activity, final int requiredMatches, final int minScreenshotsCount,
            final int intervalMs, final int timeoutMs, double threshold, boolean includeAA,
            final StabilityCallback callback) {
        String unusableReason = CompiledCore.unusableReason();
        if (unusableReason != null) {
            Log.w(TAG, "UI is not stable - the C core cannot decide: " + unusableReason);
            callback.onResult(false);
            return;
        }

        // Android's own constants: the clock starts now, before the first screenshot, and that
        // screenshot counts towards the minimum. The clock is one that never steps back.
        final boolean countsFirstScreenshot = true;
        final CompiledCore.StillnessDecision stillness = CompiledCore.StillnessDecision.begin(
                stillPairsForMatchingScreenshots(requiredMatches), minScreenshotsCount,
                countsFirstScreenshot, timeoutMs, threshold, includeAA, SystemClock.uptimeMillis());
        if (stillness == null) {
            Log.w(TAG, "UI is not stable - the C core could not start a stillness decision");
            callback.onResult(false);
            return;
        }

        final HandlerThread captureThread = new HandlerThread("SherloStabilityLoop");
        captureThread.start();
        final Handler captureHandler = new Handler(captureThread.getLooper());

        final Bitmap[] lastScreenshot = new Bitmap[1];
        final long[] differentPixels = new long[1];

        // Initial capture on background thread
        captureHandler.post(() -> {
            try {
                lastScreenshot[0] = captureScreenshot(activity);
            } catch (RuntimeException firstCaptureFailed) {
                Log.e(TAG, "UI is not stable - the first screenshot failed", firstCaptureFailed);
                callback.onResult(false);
                stillness.end();
                captureThread.quitSafely();
                return;
            }

            Runnable loop = new Runnable() {
                @Override
                public void run() {
                    try {
                        Bitmap current = captureScreenshot(activity);
                        // Android reads its clock once the screenshot is taken.
                        long capturedMs = SystemClock.uptimeMillis();

                        // Clear focus / IME on UI thread; a cleared focus starts the count and the
                        // clock again.
                        boolean[] foundFocus = new boolean[] { false };
                        runOnUiThread(activity, () -> foundFocus[0] = clearFocusAndHideIme(activity));
                        // The core restarts its clock at the time it is handed. After a cleared
                        // focus that is the time read after the clear, as before the C core; the
                        // one difference is that this step's own elapsed time is read then too,
                        // later by the length of the clear.
                        long stepMs = capturedMs;
                        if (foundFocus[0]) {
                            Log.d(TAG, "Found and cleared focus");
                            stepMs = SystemClock.uptimeMillis();
                        }

                        int verdict = stillness.step(lastScreenshot[0], current, stepMs, foundFocus[0],
                                differentPixels);
                        if (differentPixels[0] == CompiledCore.ERROR_SIZE_MISMATCH) {
                            Log.d(TAG, "Bitmaps have different dimensions");
                        } else if (differentPixels[0] == 0) {
                            Log.d(TAG, "Consecutive match");
                        } else {
                            Log.d(TAG, "No consecutive match - " + differentPixels[0] + " different pixels");
                        }

                        // Recycle previous screenshot to free memory
                        if (lastScreenshot[0] != null && !lastScreenshot[0].isRecycled()) {
                            lastScreenshot[0].recycle();
                        }
                        lastScreenshot[0] = current;

                        if (verdict == CompiledCore.STILL_STABLE) {
                            Log.d(TAG, "UI is stable");
                            finish(true);
                            return;
                        }

                        if (verdict == CompiledCore.STILL_UNSTABLE) {
                            Log.d(TAG, "UI is not stable - timeout with no matches");
                            finish(false);
                            return;
                        }

                        if (verdict != CompiledCore.STILL_CONTINUE) {
                            Log.w(TAG, "UI is not stable - the C core refused the screenshots (" + verdict + ")");
                            finish(false);
                            return;
                        }

                        // Schedule next iteration
                        captureHandler.postDelayed(this, Math.max(intervalMs, 1));
                    } catch (Throwable t) {
                        Log.e(TAG, "Stability loop error", t);
                        finish(false);
                    }
                }

                private void finish(boolean result) {
                    try {
                        callback.onResult(result);
                    } finally {
                        stillness.end();
                        try {
                            captureThread.quitSafely();
                        } catch (Throwable ignored) {
                        }
                    }
                }
            };

            captureHandler.postDelayed(loop, Math.max(intervalMs, 1));
        });
    }

    /**
     * Helps ensure UI stability by removing any blinking cursors or focus
     * highlights.
     *
     * @param activity The activity to check for focus and its children
     * @return True if a focused view was found and cleared, false otherwise
     */
    private static boolean clearFocusAndHideIme(Activity activity) {
        View root = activity.getWindow().getDecorView();
        View focused = root.findFocus();
        if (focused == null)
            return false;

        // 1) clear focus
        focused.clearFocus();

        // 2) hide IME explicitly
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
        IBinder token = focused.getWindowToken();
        if (imm != null && token != null) {
            imm.hideSoftInputFromWindow(token, 0);
        }

        // 3) prevent instant re-focus for one frame
        ViewGroup content = activity.findViewById(android.R.id.content);
        if (content != null) {
            content.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
            new Handler(Looper.getMainLooper())
                    .postDelayed(() -> content.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS), 16);
        }

        return true;
    }

    /**
     * Utility: run a small task on the UI thread and wait (up to 1s) for it to
     * complete.
     */
    private static void runOnUiThread(Activity activity, Runnable r) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            r.run();
            return;
        }
        final CountDownLatch latch = new CountDownLatch(1);
        activity.runOnUiThread(() -> {
            try {
                r.run();
            } finally {
                latch.countDown();
            }
        });
        try {
            latch.await(1000, TimeUnit.MILLISECONDS);
        } catch (InterruptedException ignored) {
        }
    }
}
